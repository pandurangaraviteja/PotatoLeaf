"""
train.py
========
10-fold stratified cross-validation training for all 8 augmentation
conditions across ResNet-50 and ViT-B/16. Implements Algorithm 2
of the paper (zip-based real/synth training loop).

Usage
-----
    python train.py --dataset plantvillage --condition A2s
    python train.py --dataset field_in     --condition A0
    python train.py --dataset plantvillage --condition all   # runs all 8

Output
------
    results/<dataset>/<condition>/<arch>/fold_<k>_metrics.json
    checkpoints/<dataset>/<condition>/<arch>/fold_<k>_best.pt
"""

from __future__ import annotations

import argparse
import json
import os
import random
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import timm
import torch
import torch.nn as nn
from sklearn.model_selection import StratifiedKFold
from torch.utils.data import DataLoader, Subset
from tqdm import tqdm

import config as C
from dataset import (
    LeafDataset,
    get_base_transform,
    get_randaugment_transform,
    get_standard_aug_transform,
    make_loaders,
)
from metrics import compute_all_metrics
from rd_aug import generate_synthetic_dataset


# ------------------------------------------------------------------
# Reproducibility
# ------------------------------------------------------------------

def set_seed(seed: int = C.SEED) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# ------------------------------------------------------------------
# Model factory
# ------------------------------------------------------------------

def build_model(arch: str, num_classes: int = C.NUM_CLASSES) -> nn.Module:
    """
    Build ResNet-50 or ViT-B/16 from timm with ImageNet-1K pretrained weights.
    Fine-tuned end-to-end (paper Sec. V-B).
    """
    if arch == "resnet50":
        model = timm.create_model(
            "resnet50",
            pretrained=True,
            num_classes=num_classes,
        )
    elif arch == "vit_b16":
        model = timm.create_model(
            "vit_base_patch16_224",
            pretrained=True,
            num_classes=num_classes,
        )
    else:
        raise ValueError(f"Unknown arch: {arch}. Choose 'resnet50' or 'vit_b16'.")
    return model


# ------------------------------------------------------------------
# One training epoch (Algorithm 2: zip iteration)
# ------------------------------------------------------------------

def train_one_epoch(
    model: nn.Module,
    real_loader: DataLoader,
    synth_loader: Optional[DataLoader],
    optimiser: torch.optim.Optimizer,
    criterion: nn.Module,
    device: torch.device,
    condition: str,
) -> float:
    """
    Train for one epoch using zip(real_loader, synth_loader).

    For conditions A4 (MixUp) and A5 (CutMix), the collate_fn returns
    soft labels (float tensors); criterion handles both hard and soft.
    For all other conditions, labels are int tensors.
    """
    model.train()
    total_loss = 0.0
    n_batches  = 0

    if synth_loader is None:
        # A0, A1, A4, A5, A6: train on real only (or real with aug/collate)
        for imgs, labels in real_loader:
            imgs   = imgs.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)

            optimiser.zero_grad()
            logits = model(imgs)

            if labels.dtype == torch.float32:
                # Soft labels from MixUp / CutMix
                loss = _soft_cross_entropy(logits, labels)
            else:
                loss = criterion(logits, labels)

            loss.backward()
            optimiser.step()
            total_loss += loss.item()
            n_batches  += 1
    else:
        # A2, A2s, A3: zip(real_loader, synth_loader)
        for (real_imgs, real_labels), (synth_imgs, synth_labels) in zip(
            real_loader, synth_loader
        ):
            imgs   = torch.cat([real_imgs,   synth_imgs],   dim=0).to(device, non_blocking=True)
            labels = torch.cat([real_labels, synth_labels], dim=0).to(device, non_blocking=True)

            optimiser.zero_grad()
            logits = model(imgs)
            loss   = criterion(logits, labels)
            loss.backward()
            optimiser.step()
            total_loss += loss.item()
            n_batches  += 1

    return total_loss / max(n_batches, 1)


def _soft_cross_entropy(logits: torch.Tensor, soft_labels: torch.Tensor) -> torch.Tensor:
    """Cross-entropy loss for soft (one-hot mixed) labels."""
    log_probs = torch.log_softmax(logits, dim=1)
    return -(soft_labels * log_probs).sum(dim=1).mean()


# ------------------------------------------------------------------
# One evaluation pass
# ------------------------------------------------------------------

@torch.no_grad()
def evaluate(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    num_classes: int = C.NUM_CLASSES,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Run model on loader; return (all_probs, all_labels) as numpy arrays.
    Probs are raw softmax outputs (no temperature scaling).
    """
    model.eval()
    all_probs  = []
    all_labels = []

    for imgs, labels in loader:
        imgs = imgs.to(device, non_blocking=True)
        logits = model(imgs)
        probs  = torch.softmax(logits, dim=1).cpu().numpy()
        all_probs.append(probs)
        all_labels.append(
            labels.numpy() if isinstance(labels, torch.Tensor)
            else np.array(labels)
        )

    return np.concatenate(all_probs), np.concatenate(all_labels)


# ------------------------------------------------------------------
# Main training loop for one condition × one architecture × one fold
# ------------------------------------------------------------------

def train_fold(
    arch: str,
    condition: str,
    train_real_dataset: LeafDataset,
    val_dataset: LeafDataset,
    synth_images: Optional[List[np.ndarray]],
    synth_labels: Optional[List[int]],
    fold_idx: int,
    dataset_name: str,
    device: torch.device,
) -> Dict:
    """Train one fold and return the best validation metrics."""
    set_seed(C.SEED + fold_idx)

    model = build_model(arch).to(device)

    # Optimiser: AdamW, lr=1e-4, weight_decay=1e-4, β1=0.9, β2=0.999
    optimiser = torch.optim.AdamW(
        model.parameters(),
        lr=C.LR,
        weight_decay=C.WEIGHT_DECAY,
        betas=(C.BETA1, C.BETA2),
    )

    # Cosine LR annealing (paper Sec. V-B)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimiser, T_max=C.EPOCHS
    )

    criterion = nn.CrossEntropyLoss()

    # Build DataLoaders
    real_loader, synth_loader = make_loaders(
        real_dataset=train_real_dataset,
        synth_images=synth_images,
        synth_labels=synth_labels,
        condition=condition,
        batch_size=C.BATCH_SIZE,
        seed=C.SEED + fold_idx,
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=C.BATCH_SIZE * 2,
        shuffle=False,
        num_workers=4,
        pin_memory=True,
    )

    best_acc  = 0.0
    best_metrics = {}
    ckpt_dir  = (
        Path(C.CHECKPOINT_DIR) / dataset_name / condition / arch
    )
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    ckpt_path = ckpt_dir / f"fold_{fold_idx:02d}_best.pt"

    for epoch in range(1, C.EPOCHS + 1):
        t0   = time.time()
        loss = train_one_epoch(
            model, real_loader, synth_loader, optimiser,
            criterion, device, condition,
        )
        scheduler.step()

        # Validate every 5 epochs and on last epoch
        if epoch % 5 == 0 or epoch == C.EPOCHS:
            probs, true_labels = evaluate(model, val_loader, device)
            metrics = compute_all_metrics(probs, true_labels)
            elapsed = time.time() - t0

            print(
                f"  [{arch}|{condition}|fold {fold_idx}] "
                f"epoch {epoch:3d}/{C.EPOCHS} "
                f"loss={loss:.4f} "
                f"acc={metrics['accuracy']:.2f}% "
                f"ece={metrics['ece']:.4f} "
                f"({elapsed:.1f}s)"
            )

            if metrics["accuracy"] > best_acc:
                best_acc     = metrics["accuracy"]
                best_metrics = metrics
                torch.save(model.state_dict(), ckpt_path)

    print(
        f"  ✓ Best fold {fold_idx}: "
        f"acc={best_acc:.2f}% auc={best_metrics.get('auc',0):.4f} "
        f"f1={best_metrics.get('f1',0):.4f} ece={best_metrics.get('ece',0):.4f}"
    )
    return best_metrics


# ------------------------------------------------------------------
# 10-fold cross-validation driver
# ------------------------------------------------------------------

def run_cv(
    dataset_name: str,
    condition: str,
    arch: str,
    device: torch.device,
) -> List[Dict]:
    """
    Run 10-fold stratified CV for one condition × arch × dataset.
    Returns list of per-fold metric dicts.
    """
    print(f"\n{'='*60}")
    print(f"  Dataset={dataset_name}  Condition={condition}  Arch={arch}")
    print(f"{'='*60}")

    root = C.PLANTVILLAGE_ROOT if dataset_name == "plantvillage" else C.FIELDIN_ROOT
    # Determine transform for real images based on condition
    if condition == "A1":
        real_transform = get_standard_aug_transform()
    elif condition == "A6":
        real_transform = get_randaugment_transform()
    else:
        real_transform = get_base_transform()

    full_dataset = LeafDataset(root=root, transform=real_transform)
    all_labels   = full_dataset.labels
    all_indices  = list(range(len(full_dataset)))

    skf = StratifiedKFold(
        n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED
    )

    fold_results = []

    for fold_idx, (train_idx, val_idx) in enumerate(
        skf.split(all_indices, all_labels)
    ):
        print(f"\n--- Fold {fold_idx+1}/{C.N_FOLDS} "
              f"(train={len(train_idx)}, val={len(val_idx)}) ---")

        train_real_ds = Subset(full_dataset, train_idx)
        val_ds        = Subset(
            LeafDataset(root=root, transform=get_base_transform()),
            val_idx,
        )

        # ---- Generate synthetic images if needed ----
        synth_images = None
        synth_labels = None

        if condition in ("A2", "A2s", "A3"):
            # Load healthy images for backgrounds
            healthy_images = _load_healthy_images(
                root=root, indices=train_idx, full_dataset=full_dataset
            )

            stochastic     = (condition in ("A2s",))
            shuffle_frames = (condition == "A3")

            synth_images, synth_labels = generate_synthetic_dataset(
                healthy_images=healthy_images,
                n_per_class=C.SYNTH_PER_CLASS,
                stochastic=stochastic,
                shuffle_frames=shuffle_frames,
                seed=C.SEED + fold_idx,
            )

        metrics = train_fold(
            arch=arch,
            condition=condition,
            train_real_dataset=train_real_ds,
            val_dataset=val_ds,
            synth_images=synth_images,
            synth_labels=synth_labels,
            fold_idx=fold_idx + 1,
            dataset_name=dataset_name,
            device=device,
        )
        fold_results.append(metrics)

    # Save results
    _save_fold_results(fold_results, dataset_name, condition, arch)
    _print_summary(fold_results, dataset_name, condition, arch)
    return fold_results


def _load_healthy_images(
    root: str,
    indices: List[int],
    full_dataset: LeafDataset,
    max_images: int = 400,
) -> List[np.ndarray]:
    """Load healthy leaf images from the training split as RGB numpy arrays."""
    healthy = []
    for idx in indices:
        path, label = full_dataset.samples[idx]
        if label == C.LABEL_HEALTHY:
            img = np.array(
                Image.open(path).convert("RGB")
                     .resize((C.IMG_SIZE, C.IMG_SIZE))
            )
            healthy.append(img)
        if len(healthy) >= max_images:
            break
    if len(healthy) == 0:
        # Fallback: create a uniform green background
        healthy = [np.full((C.IMG_SIZE, C.IMG_SIZE, 3), [80, 120, 60], dtype=np.uint8)]
    return healthy


def _save_fold_results(
    fold_results: List[Dict],
    dataset_name: str,
    condition: str,
    arch: str,
) -> None:
    out_dir = Path(C.RESULTS_DIR) / dataset_name / condition / arch
    out_dir.mkdir(parents=True, exist_ok=True)
    for i, metrics in enumerate(fold_results):
        with open(out_dir / f"fold_{i+1:02d}_metrics.json", "w") as f:
            json.dump(metrics, f, indent=2)
    # Also save aggregated
    agg = {
        k: {
            "mean": float(np.mean([m[k] for m in fold_results])),
            "std":  float(np.std([m[k] for m in fold_results])),
        }
        for k in fold_results[0].keys()
    }
    with open(out_dir / "aggregated.json", "w") as f:
        json.dump(agg, f, indent=2)


def _print_summary(
    fold_results: List[Dict],
    dataset_name: str,
    condition: str,
    arch: str,
) -> None:
    accs = [m["accuracy"] for m in fold_results]
    aucs = [m["auc"]      for m in fold_results]
    f1s  = [m["f1"]       for m in fold_results]
    eces = [m["ece"]      for m in fold_results]
    print(f"\n{'─'*60}")
    print(f"  SUMMARY  {dataset_name} | {condition} | {arch}")
    print(f"  Acc : {np.mean(accs):.2f} ± {np.std(accs):.2f}%")
    print(f"  AUC : {np.mean(aucs):.4f} ± {np.std(aucs):.4f}")
    print(f"  F1  : {np.mean(f1s):.4f} ± {np.std(f1s):.4f}")
    print(f"  ECE : {np.mean(eces):.4f} ± {np.std(eces):.4f}")
    print(f"{'─'*60}")


# ------------------------------------------------------------------
# CLI entry point
# ------------------------------------------------------------------

ALL_CONDITIONS = ["A0", "A1", "A2", "A2s", "A3", "A4", "A5", "A6"]
ALL_ARCHS      = ["vit_b16", "resnet50"]
ALL_DATASETS   = ["plantvillage", "field_in"]


def main() -> None:
    parser = argparse.ArgumentParser(
        description="RD-Aug: 10-fold CV training for all paper conditions"
    )
    parser.add_argument("--dataset",   choices=ALL_DATASETS + ["all"],
                        default="plantvillage")
    parser.add_argument("--condition", choices=ALL_CONDITIONS + ["all"],
                        default="A2s")
    parser.add_argument("--arch",      choices=ALL_ARCHS + ["all"],
                        default="vit_b16")
    parser.add_argument("--gpu",       type=int, default=0)
    args = parser.parse_args()

    device = torch.device(
        f"cuda:{args.gpu}" if torch.cuda.is_available() else "cpu"
    )
    print(f"[train] Using device: {device}")
    set_seed()

    datasets   = ALL_DATASETS   if args.dataset   == "all" else [args.dataset]
    conditions = ALL_CONDITIONS if args.condition  == "all" else [args.condition]
    archs      = ALL_ARCHS      if args.arch       == "all" else [args.arch]

    for ds in datasets:
        for cond in conditions:
            for arch in archs:
                run_cv(
                    dataset_name=ds,
                    condition=cond,
                    arch=arch,
                    device=device,
                )

    print("\n[train] All runs complete. Results saved to:", C.RESULTS_DIR)


if __name__ == "__main__":
    main()
