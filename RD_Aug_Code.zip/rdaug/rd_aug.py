"""
rd_aug.py
=========
Fisher--KPP reaction-diffusion synthetic lesion generation.
Implements Algorithm 1 of the paper exactly, including:
  - Forward-Euler discretisation with CFL check
  - Neumann (reflecting) boundary conditions
  - 70 sub-steps per frame, 6 frames total
  - Deterministic (A2) and stochastic (A2s) nucleation
  - Alpha-blending onto healthy leaf backgrounds
  - Stage label assignment at 30% of K threshold

All parameters come from config.py.
"""

from __future__ import annotations

import math
import random
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
from PIL import Image

import config as C


# ------------------------------------------------------------------
# Core PDE solver
# ------------------------------------------------------------------

def _five_point_laplacian(C_field: np.ndarray) -> np.ndarray:
    """
    Five-point discrete Laplacian with Neumann (reflecting) BCs.

    Ghost-cell implementation: each edge pixel reflects across the boundary,
    making dC/dn = 0 at all four borders.

    Parameters
    ----------
    C_field : np.ndarray, shape (H, W), dtype float64

    Returns
    -------
    L : np.ndarray, shape (H, W), dtype float64
    """
    C_pad = np.pad(C_field, 1, mode="reflect")
    L = (C_pad[:-2, 1:-1] + C_pad[2:, 1:-1]
       + C_pad[1:-1, :-2] + C_pad[1:-1, 2:]
       - 4 * C_field)
    return L


def _euler_step(
    C: np.ndarray,
    D: float,
    r: float,
    K: float,
    dt: float,
) -> np.ndarray:
    """
    Single forward-Euler step of the Fisher--KPP equation.

    C_{n+1} = C_n + dt * [D * Laplacian(C_n) + r * C_n * (1 - C_n/K)]

    Parameters match paper Eq. (5).
    """
    L = _five_point_laplacian(C)
    dC = dt * (D * L + r * C * (1.0 - C / K))
    C_new = C + dC
    # Clip to [0, K] to prevent numerical overshoot
    return np.clip(C_new, 0.0, K)


def _field_to_uint8(C: np.ndarray) -> np.ndarray:
    """
    Map concentration field to 8-bit grayscale image.
    I(x,t) = floor(255 * C(x,t) / max_x C(x,t))   [paper Eq. 6]
    """
    max_val = C.max()
    if max_val < 1e-12:
        return np.zeros(C.shape, dtype=np.uint8)
    return np.floor(255.0 * C / max_val).astype(np.uint8)


def generate_lesion_sequence(
    height: int = C.IMG_SIZE,
    width: int = C.IMG_SIZE,
    D: float = C.RD_D,
    r: float = C.RD_R,
    K: float = C.RD_K,
    M: int = C.RD_M,
    sigma: float = C.RD_SIGMA,
    T: int = C.RD_T,
    n_sub: int = C.RD_NSUB,
    dt: float = C.RD_DT,
    stochastic: bool = True,
    fixed_centers: Optional[List[Tuple[int, int]]] = None,
    fixed_amplitudes: Optional[List[float]] = None,
    rng: Optional[np.random.Generator] = None,
) -> List[np.ndarray]:
    """
    Generate a sequence of T+1 lesion-progression frames (Algorithm 1).

    Parameters
    ----------
    height, width : int
        Spatial domain size (px). Paper uses 224×224.
    D, r, K : float
        PDE parameters. Wave speed v* = 2*sqrt(D*r) = 1.22 px/time-unit.
    M : int
        Number of inoculation nuclei.
    sigma : float
        Gaussian inoculum width (px). Paper: 8 px.
    T : int
        Number of output frames (not counting frame 0). Paper: 6.
    n_sub : int
        Forward-Euler sub-steps per frame. Paper: 70.
    dt : float
        Euler time step. Paper: 0.05. CFL limit = h²/(4D) = 1.0.
    stochastic : bool
        If True (A2s), resample nucleation sites and amplitudes each call.
        If False (A2), use fixed_centers and fixed_amplitudes.
    fixed_centers : list of (row, col) pairs, optional
        Used only when stochastic=False.
    fixed_amplitudes : list of floats, optional
        Used only when stochastic=False.
    rng : np.random.Generator, optional
        For reproducibility. Created from config.SEED if None.

    Returns
    -------
    frames : list of np.ndarray, shape (H, W), dtype uint8
        Length T+1, i.e., frames[0] through frames[T].
        frames[0] = initial field; frames[k] = state after k frames.
    """
    # CFL check (paper Sec. III-D)
    h = 1.0
    cfl_limit = h ** 2 / (4.0 * D)
    assert dt <= cfl_limit, (
        f"CFL stability violated: dt={dt} > h²/(4D)={cfl_limit:.4f}"
    )

    if rng is None:
        rng = np.random.default_rng(C.SEED)

    # ---- Initial condition: superimpose M Gaussian inocula ----
    # paper Eq. (3)
    yy, xx = np.mgrid[0:height, 0:width].astype(float)

    if stochastic:
        # A2s: sample xi ~ U(Omega), Ai ~ U(0.5, 1]
        centers = [
            (rng.integers(0, height), rng.integers(0, width))
            for _ in range(M)
        ]
        amplitudes = rng.uniform(0.5, 1.0, size=M).tolist()
    else:
        # A2: use provided fixed positions
        assert fixed_centers is not None and fixed_amplitudes is not None, (
            "stochastic=False requires fixed_centers and fixed_amplitudes"
        )
        centers = fixed_centers
        amplitudes = fixed_amplitudes

    C_field = np.zeros((height, width), dtype=float)
    for (cy, cx), A in zip(centers, amplitudes):
        dist_sq = (yy - cy) ** 2 + (xx - cx) ** 2
        C_field += A * np.exp(-dist_sq / (2.0 * sigma ** 2))
    C_field = np.clip(C_field, 0.0, K)

    frames = [_field_to_uint8(C_field)]  # frame 0

    # ---- Outer loop: T frames; each frame = n_sub Euler sub-steps ----
    for k in range(T):
        for _ in range(n_sub):
            # 70 sub-steps × dt=0.05 = 3.5 time-units per frame
            C_field = _euler_step(C_field, D, r, K, dt)
        frames.append(_field_to_uint8(C_field))

    return frames  # length T+1


# ------------------------------------------------------------------
# Stage label assignment
# ------------------------------------------------------------------

def assign_stage_label(
    frame_idx: int,
    C_mean_frac: Optional[float] = None,
    thresh: float = C.RD_THRESH,
) -> int:
    """
    Assign blight stage label to a frame.

    Paper Sec. IV-B:
      frames 0-1 (mean C < 0.3K) → early blight (label 1)
      frames 2-5 (mean C ≥ 0.3K) → late blight  (label 2)

    Parameters
    ----------
    frame_idx : int
        0-indexed frame number.
    C_mean_frac : float, optional
        Actual mean C / K for this frame. If None, uses frame_idx heuristic.
    thresh : float
        Threshold on C/K.  Paper: 0.3.

    Returns
    -------
    int : LABEL_EARLY_BLIGHT (1) or LABEL_LATE_BLIGHT (2)
    """
    if C_mean_frac is not None:
        return C.LABEL_EARLY_BLIGHT if C_mean_frac < thresh else C.LABEL_LATE_BLIGHT
    # Heuristic from paper (frames 0-1 → early; 2-5 → late)
    return C.LABEL_EARLY_BLIGHT if frame_idx <= 1 else C.LABEL_LATE_BLIGHT


# ------------------------------------------------------------------
# Alpha-blending compositor
# ------------------------------------------------------------------

def composite_lesion(
    lesion_gray: np.ndarray,
    background_rgb: np.ndarray,
    alpha: float = C.RD_ALPHA,
    leaf_mask: Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Alpha-composite a grayscale lesion field onto an RGB background.

    tilde_I(x, t_k) = alpha * I(x, t_k) + (1-alpha) * B(x)   [paper Eq. 7]

    The lesion is applied only within the leaf mask (if provided).

    Parameters
    ----------
    lesion_gray : np.ndarray, shape (H, W), dtype uint8
        8-bit grayscale concentration field from generate_lesion_sequence().
    background_rgb : np.ndarray, shape (H, W, 3), dtype uint8
        Healthy leaf image.
    alpha : float
        Blending weight. Paper: 0.7.
    leaf_mask : np.ndarray, shape (H, W), dtype bool, optional
        Binary mask of the leaf surface. If None, applies globally.

    Returns
    -------
    composite : np.ndarray, shape (H, W, 3), dtype uint8
    """
    H, W = background_rgb.shape[:2]
    lesion_float = lesion_gray.astype(float) / 255.0

    # Convert grayscale lesion to RGB by replicating to 3 channels
    # and tinting toward a brownish disease colour (approximation)
    lesion_rgb = np.stack([
        (lesion_float * 0.55 * 255).clip(0, 255),   # R
        (lesion_float * 0.35 * 255).clip(0, 255),   # G
        (lesion_float * 0.10 * 255).clip(0, 255),   # B
    ], axis=2).astype(float)

    bg_float = background_rgb.astype(float)
    composite = alpha * lesion_rgb + (1.0 - alpha) * bg_float

    if leaf_mask is not None:
        mask3 = np.stack([leaf_mask] * 3, axis=2)
        composite = np.where(mask3, composite, bg_float)

    return composite.clip(0, 255).astype(np.uint8)


# ------------------------------------------------------------------
# Full synthetic dataset generator
# ------------------------------------------------------------------

def generate_synthetic_dataset(
    healthy_images: List[np.ndarray],
    n_per_class: int = C.SYNTH_PER_CLASS,
    stochastic: bool = True,
    shuffle_frames: bool = False,
    output_dir: Optional[str] = None,
    seed: int = C.SEED,
) -> Tuple[List[np.ndarray], List[int]]:
    """
    Generate the full RD-Aug synthetic dataset.

    For each of n_per_class early-blight images and n_per_class late-blight
    images:
      1. Run generate_lesion_sequence() to get T+1 frames.
      2. Select the appropriate frame (early or late) by stage label.
      3. Pick a random healthy background and composite.

    The returned list is in temporal order (incipient frames first)
    when shuffle_frames=False (A2/A2s), or randomly shuffled (A3).

    Parameters
    ----------
    healthy_images : list of np.ndarray, shape (224, 224, 3)
        Pool of healthy leaf images to use as backgrounds.
    n_per_class : int
        Number of synthetic images per blight stage. Paper: 600.
    stochastic : bool
        True → A2s (resample nucleation per image).
        False → A2  (fixed nucleation sites per run).
    shuffle_frames : bool
        True  → A3 (shuffle temporal order).
        False → A2/A2s (preserve temporal order for implicit curriculum).
    output_dir : str, optional
        If provided, save PNG images here.
    seed : int
        RNG seed.

    Returns
    -------
    images : list of np.ndarray, shape (224, 224, 3), dtype uint8
    labels : list of int  (LABEL_EARLY_BLIGHT or LABEL_LATE_BLIGHT)
    """
    rng = np.random.default_rng(seed)
    py_rng = random.Random(seed)

    images_early: List[np.ndarray] = []
    images_late:  List[np.ndarray] = []

    # Fixed nucleation for A2 (deterministic)
    fixed_centers = [
        (int(rng.integers(20, C.IMG_SIZE - 20)),
         int(rng.integers(20, C.IMG_SIZE - 20)))
        for _ in range(C.RD_M)
    ]
    fixed_amplitudes = [0.8, 0.9, 0.7]   # deterministic amplitudes for A2

    print(f"[rd_aug] Generating {n_per_class} early + {n_per_class} late "
          f"synthetic images (stochastic={stochastic}, shuffle={shuffle_frames})")

    for i in range(n_per_class):
        # Generate a full progression sequence
        frames = generate_lesion_sequence(
            stochastic=stochastic,
            fixed_centers=fixed_centers,
            fixed_amplitudes=fixed_amplitudes,
            rng=rng,
        )

        # Pick background
        bg = py_rng.choice(healthy_images)

        # Early blight: take frame 0 or 1 (low C)
        early_frame_idx = py_rng.choice(C.EARLY_FRAMES)
        img_early = composite_lesion(frames[early_frame_idx], bg)
        images_early.append(img_early)

        # Late blight: take frame 2-5 (high C)
        late_frame_idx = py_rng.choice(C.LATE_FRAMES)
        img_late = composite_lesion(frames[late_frame_idx], bg)
        images_late.append(img_late)

        if (i + 1) % 100 == 0:
            print(f"  [{i+1}/{n_per_class}] sequences generated")

    # Assemble in temporal order: all early before all late
    # This is what creates the implicit curriculum when shuffle_frames=False
    ordered_images = images_early + images_late
    ordered_labels = (
        [C.LABEL_EARLY_BLIGHT] * n_per_class
        + [C.LABEL_LATE_BLIGHT] * n_per_class
    )

    if shuffle_frames:
        # A3: destroy temporal order
        combined = list(zip(ordered_images, ordered_labels))
        py_rng.shuffle(combined)
        ordered_images, ordered_labels = zip(*combined)
        ordered_images = list(ordered_images)
        ordered_labels = list(ordered_labels)

    if output_dir is not None:
        _save_synthetic(ordered_images, ordered_labels, output_dir)

    return ordered_images, ordered_labels


def _save_synthetic(
    images: List[np.ndarray],
    labels: List[int],
    output_dir: str,
) -> None:
    """Save synthetic images to disk as PNGs in class subfolders."""
    label_to_name = {
        C.LABEL_EARLY_BLIGHT: "early_blight",
        C.LABEL_LATE_BLIGHT:  "late_blight",
    }
    out = Path(output_dir)
    for cls_name in label_to_name.values():
        (out / cls_name).mkdir(parents=True, exist_ok=True)

    counts = {k: 0 for k in label_to_name}
    for img, label in zip(images, labels):
        cls_name = label_to_name[label]
        counts[label] += 1
        fname = out / cls_name / f"synth_{counts[label]:05d}.png"
        Image.fromarray(img).save(fname)

    print(f"[rd_aug] Saved {sum(counts.values())} synthetic images to {output_dir}")


# ------------------------------------------------------------------
# Quick self-test
# ------------------------------------------------------------------

if __name__ == "__main__":
    print(f"Wave speed v* = {C.WAVE_SPEED:.4f} px/time-unit")
    print(f"Time per frame = {C.TIME_PER_FRAME:.1f} time-units")
    print(f"Radial advance per frame = {C.RADIAL_ADVANCE_PER_FRAME:.2f} px")

    # Generate one sequence with fixed seed
    rng = np.random.default_rng(42)
    frames = generate_lesion_sequence(stochastic=True, rng=rng)
    assert len(frames) == C.RD_T + 1, f"Expected {C.RD_T+1} frames, got {len(frames)}"

    for k, f in enumerate(frames):
        label = assign_stage_label(k)
        stage = "early" if label == C.LABEL_EARLY_BLIGHT else "late"
        print(f"  Frame {k}: max={f.max()}, mean={f.mean():.1f} → {stage} blight")

    print("rd_aug.py self-test passed.")
