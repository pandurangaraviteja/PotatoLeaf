"""
metrics.py
==========
All evaluation metrics reported in the paper.

  - Macro-averaged accuracy, AUC (one-vs-rest), F1
  - ECE: raw softmax, 15 equal-width bins, no calibration  (paper Sec. V-B)
  - Wilcoxon signed-rank test (one-tailed and two-tailed)  (paper Sec. V-D)
  - Sign-flip permutation test                             (paper Sec. V-D)
  - 95% bootstrap confidence intervals                     (paper Sec. V-D)
  - Mann-Whitney U tests for morphological validation      (paper Sec. V-C)
  - Cohen's kappa for Grad-CAM annotator agreement         (paper Sec. V-I)
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.stats import mannwhitneyu, wilcoxon
from sklearn.metrics import (
    accuracy_score,
    cohen_kappa_score,
    f1_score,
    roc_auc_score,
)

import config as C


# ------------------------------------------------------------------
# Primary metrics bundle
# ------------------------------------------------------------------

def compute_all_metrics(
    probs: np.ndarray,
    true_labels: np.ndarray,
    num_classes: int = C.NUM_CLASSES,
    ece_bins: int = C.ECE_BINS,
) -> Dict[str, float]:
    """
    Compute accuracy, AUC, F1, and ECE from softmax probabilities.

    Parameters
    ----------
    probs : np.ndarray, shape (N, num_classes)
        Raw softmax probabilities (no temperature scaling).
    true_labels : np.ndarray, shape (N,), dtype int
        Ground-truth class indices.
    num_classes : int
        Number of classes. Paper: 3.
    ece_bins : int
        Number of equal-width confidence bins. Paper: 15.

    Returns
    -------
    dict with keys: accuracy, auc, f1, ece
    """
    pred_labels = probs.argmax(axis=1)

    acc = accuracy_score(true_labels, pred_labels) * 100.0

    # One-vs-rest macro AUC
    try:
        auc = roc_auc_score(
            true_labels, probs,
            multi_class="ovr", average="macro"
        )
    except ValueError:
        auc = float("nan")

    f1 = f1_score(true_labels, pred_labels, average="macro", zero_division=0)

    ece = compute_ece(probs, true_labels, n_bins=ece_bins)

    return {"accuracy": acc, "auc": auc, "f1": f1, "ece": ece}


# ------------------------------------------------------------------
# ECE: Expected Calibration Error
# ------------------------------------------------------------------

def compute_ece(
    probs: np.ndarray,
    true_labels: np.ndarray,
    n_bins: int = C.ECE_BINS,
) -> float:
    """
    Expected Calibration Error (raw softmax; equal-width bins).

    ECE = sum_b (|B_b| / N) * |acc(B_b) - conf(B_b)|

    Parameters match paper Sec. V-B:
      - raw softmax probabilities (no post-hoc calibration)
      - 15 equal-width confidence bins
      - confidence = max softmax probability

    Parameters
    ----------
    probs : np.ndarray, shape (N, C)
    true_labels : np.ndarray, shape (N,)
    n_bins : int

    Returns
    -------
    ece : float
    """
    N = len(true_labels)
    confidences = probs.max(axis=1)
    predictions = probs.argmax(axis=1)
    correct     = (predictions == true_labels).astype(float)

    bin_edges = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0

    for i in range(n_bins):
        lo, hi = bin_edges[i], bin_edges[i + 1]
        mask = (confidences > lo) & (confidences <= hi)
        if mask.sum() == 0:
            continue
        bin_acc  = correct[mask].mean()
        bin_conf = confidences[mask].mean()
        ece += (mask.sum() / N) * abs(bin_acc - bin_conf)

    return float(ece)


# ------------------------------------------------------------------
# Statistical tests (paper Sec. V-D)
# ------------------------------------------------------------------

def wilcoxon_test(
    scores_a: List[float],
    scores_b: List[float],
    alternative: str = "greater",
) -> Tuple[float, float, float, float]:
    """
    Wilcoxon signed-rank test between two sets of paired fold scores.

    Parameters
    ----------
    scores_a, scores_b : list of float, same length (n_folds = 10)
    alternative : 'greater' (one-tailed) or 'two-sided'

    Returns
    -------
    W : float          — Wilcoxon W statistic
    Z : float          — normal approximation Z score
    p : float          — p-value
    r : float          — effect size r = Z / sqrt(n)
    """
    a = np.array(scores_a)
    b = np.array(scores_b)
    n = len(a)

    result = wilcoxon(a, b, alternative=alternative)
    W = float(result.statistic)
    p = float(result.pvalue)

    # Z-score for effect size: r = Z/sqrt(n)
    # scipy does not return Z directly; compute from p-value approximation
    from scipy.stats import norm
    if alternative == "greater":
        Z = norm.ppf(1.0 - p)
    else:
        Z = norm.ppf(1.0 - p / 2.0)
    Z = abs(Z)
    r = Z / np.sqrt(n)

    return W, Z, p, r


def sign_flip_permutation_test(
    scores_a: List[float],
    scores_b: List[float],
    n_permutations: int = 10_000,
    seed: int = C.SEED,
) -> float:
    """
    Sign-flip permutation test for paired fold scores (paper Sec. V-D).

    For each permutation, independently flip the sign of each fold-level
    (A - B) difference with probability 0.5. Test statistic = mean signed
    difference. p = fraction of permutations exceeding observed mean diff.

    Parameters
    ----------
    scores_a, scores_b : list of float (n_folds = 10)
    n_permutations : int. Paper: 10 000.
    seed : int

    Returns
    -------
    p_value : float
    """
    rng  = np.random.default_rng(seed)
    diffs = np.array(scores_a) - np.array(scores_b)   # shape (n,)
    observed_mean = diffs.mean()

    # Generate sign-flip matrix: shape (n_permutations, n_folds)
    signs = rng.choice([-1.0, 1.0], size=(n_permutations, len(diffs)))
    perm_means = (signs * diffs[np.newaxis, :]).mean(axis=1)

    p_value = float((perm_means >= observed_mean).mean())
    return p_value


def bootstrap_ci(
    scores: List[float],
    n_resamples: int = 10_000,
    ci_level: float = 0.95,
    seed: int = C.SEED,
) -> Tuple[float, float]:
    """
    Bootstrap 95% CI for fold-level accuracy scores (paper Sec. V-D).

    Parameters
    ----------
    scores : list of float (fold accuracies)
    n_resamples : int. Paper: 10 000.
    ci_level : float. Paper: 0.95.

    Returns
    -------
    (lower, upper) : float, float
    """
    rng    = np.random.default_rng(seed)
    arr    = np.array(scores)
    boot   = rng.choice(arr, size=(n_resamples, len(arr)), replace=True)
    means  = boot.mean(axis=1)
    alpha  = 1.0 - ci_level
    lower  = float(np.percentile(means, 100 * alpha / 2))
    upper  = float(np.percentile(means, 100 * (1 - alpha / 2)))
    return lower, upper


# ------------------------------------------------------------------
# Morphological validation statistics (paper Sec. V-C)
# ------------------------------------------------------------------

def mann_whitney_u(
    real_vals: np.ndarray,
    synth_vals: np.ndarray,
) -> Tuple[float, float]:
    """
    Two-sided Mann-Whitney U test between real and synthetic descriptor
    distributions. p > 0.05 = no significant difference (paper Sec. V-C).

    Returns
    -------
    U : float
    p : float
    """
    result = mannwhitneyu(real_vals, synth_vals, alternative="two-sided")
    return float(result.statistic), float(result.pvalue)


def cohens_kappa(labels_a: np.ndarray, labels_b: np.ndarray) -> float:
    """
    Cohen's kappa for inter-annotator agreement (paper Sec. V-I).
    Paper reports kappa = 0.83.
    """
    return float(cohen_kappa_score(labels_a, labels_b))


# ------------------------------------------------------------------
# Full statistical report for a condition pair
# ------------------------------------------------------------------

def full_statistical_report(
    fold_scores: Dict[str, List[float]],
    primary_condition: str = "A2s",
    seed: int = C.SEED,
) -> Dict:
    """
    Reproduce the complete statistical analysis from paper Sec. V-D.

    Parameters
    ----------
    fold_scores : dict mapping condition_id → list of fold accuracy scores
        e.g. {'A0': [...], 'A2s': [...], 'A3': [...], 'A6': [...]}
    primary_condition : str. Paper's proposed method: 'A2s'.

    Returns
    -------
    dict with all Wilcoxon, permutation, CI results
    """
    a_scores = fold_scores[primary_condition]
    report   = {}

    comparisons = [
        # (label, condition_b, alternative)
        ("A2s_vs_A3", "A3", "greater"),   # temporal ordering (one-tailed)
        ("A2s_vs_A6", "A6", "two-sided"), # vs RandAugment
        ("A0_vs_A2s", "A0", "two-sided"), # vs real-only baseline
    ]

    for label, cond_b, alt in comparisons:
        if cond_b not in fold_scores:
            continue
        b_scores = fold_scores[cond_b]

        W, Z, p_wilcoxon, r = wilcoxon_test(a_scores, b_scores, alternative=alt)

        p_perm = None
        if label == "A2s_vs_A3":
            p_perm = sign_flip_permutation_test(
                a_scores, b_scores, n_permutations=10_000, seed=seed
            )

        report[label] = {
            "W":           W,
            "Z":           round(Z, 3),
            "p_wilcoxon":  round(p_wilcoxon, 4),
            "r":           round(r, 2),
            "alternative": alt,
            "p_permutation": round(p_perm, 4) if p_perm is not None else None,
        }

    ci_lo, ci_hi = bootstrap_ci(a_scores, n_resamples=10_000, seed=seed)
    report["bootstrap_ci_95"] = {
        "lower": round(ci_lo, 2),
        "upper": round(ci_hi, 2),
    }

    return report


if __name__ == "__main__":
    # Quick sanity check with synthetic fold scores
    rng = np.random.default_rng(42)
    mock_scores = {
        "A0":  rng.uniform(89, 92, 10).tolist(),
        "A3":  rng.uniform(94, 96, 10).tolist(),
        "A6":  rng.uniform(94, 97, 10).tolist(),
        "A2s": rng.uniform(96, 98, 10).tolist(),
    }
    report = full_statistical_report(mock_scores)
    for k, v in report.items():
        print(f"  {k}: {v}")
    print("metrics.py self-test passed.")
