"""
evaluate.py
===========
Post-training evaluation producing all tables and statistics from the paper.

  1. Aggregate fold results → Table III / IV (ablation)
  2. Statistical significance tests → paper Sec. V-D
  3. Cross-dataset transfer → Table VI
  4. Parameter sensitivity → Table VII
  5. Grad-CAM heatmaps + IoU → Table VIII

Usage
-----
    python evaluate.py --dataset plantvillage
    python evaluate.py --dataset all --transfer
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn
from PIL import Image
from torch.utils.data import DataLoader
from torchvision import transforms

import config as C
from dataset import LeafDataset, get_base_transform
from metrics import (
    bootstrap_ci,
    compute_all_metrics,
    full_statistical_report,
)
from train import ALL_CONDITIONS, ALL_ARCHS, ALL_DATASETS, build_model, evaluate


# ------------------------------------------------------------------
# Load saved fold metrics
# ------------------------------------------------------------------

def load_fold_results(
    dataset_name: str,
    condition: str,
    arch: str,
) -> List[Dict]:
    """Load per-fold metric dicts from results directory."""
    results_dir = Path(C.RESULTS_DIR) / dataset_name / condition / arch
    fold_files  = sorted(results_dir.glob("fold_*_metrics.json"))
    if not fold_files:
        return []
    return [json.loads(f.read_text()) for f in fold_files]


def aggregate_results(fold_results: List[Dict]) -> Dict:
    """Mean ± std for each metric across folds."""
    if not fold_results:
        return {}
    return {
        k: {
            "mean": float(np.mean([m[k] for m in fold_results])),
            "std":  float(np.std([m[k]  for m in fold_results])),
            "values": [m[k] for m in fold_results],
        }
        for k in fold_results[0].keys()
    }


# ------------------------------------------------------------------
# Print full ablation table (Table III / IV of the paper)
# ------------------------------------------------------------------

def print_ablation_table(dataset_name: str, arch: str) -> None:
    """Print ablation table for one dataset × arch combination."""
    print(f"\n{'='*72}")
    print(f"  Ablation Table — {dataset_name.upper()} | {arch}")
    print(f"{'='*72}")
    print(f"  {'ID':<5} {'Setting':<30} {'Acc':>7} {'AUC':>7} {'F1':>7} {'ECE':>7}")
    print(f"  {'-'*60}")

    CONDITION_LABELS = {
        "A0":  "Real only",
        "A1":  "Std. aug.",
        "A4":  "MixUp",
        "A5":  "CutMix",
        "A6":  "RandAugment",
        "A3":  "KPP shuffled",
        "A2":  "KPP ordered (det.)",
        "A2s": "KPP ordered (stoch.) [proposed]",
    }
    ORDER = ["A0", "A1", "A4", "A5", "A6", "A3", "A2", "A2s"]

    for cond in ORDER:
        fold_results = load_fold_results(dataset_name, cond, arch)
        agg = aggregate_results(fold_results)
        if not agg:
            print(f"  {cond:<5} {'(no results)':<30}")
            continue
        acc = agg["accuracy"]["mean"]
        auc = agg["auc"]["mean"]
        f1  = agg["f1"]["mean"]
        ece = agg["ece"]["mean"]
        marker = " ◀" if cond == "A2s" else ""
        print(
            f"  {cond:<5} {CONDITION_LABELS[cond]:<30} "
            f"{acc:>6.1f}% {auc:>7.4f} {f1:>7.4f} {ece:>7.4f}{marker}"
        )


# ------------------------------------------------------------------
# Statistical significance report
# ------------------------------------------------------------------

def print_statistics(dataset_name: str, arch: str) -> None:
    """Run all Wilcoxon + permutation tests from paper Sec. V-D."""
    print(f"\n{'='*72}")
    print(f"  Statistical Significance — {dataset_name.upper()} | {arch}")
    print(f"{'='*72}")

    fold_scores: Dict[str, List[float]] = {}
    for cond in ["A0", "A3", "A6", "A2s"]:
        fold_results = load_fold_results(dataset_name, cond, arch)
        if fold_results:
            fold_scores[cond] = [m["accuracy"] for m in fold_results]

    if "A2s" not in fold_scores:
        print("  No A2s results found.")
        return

    report = full_statistical_report(fold_scores, primary_condition="A2s")

    for k, v in report.items():
        if k == "bootstrap_ci_95":
            print(f"\n  Bootstrap 95% CI (A2s accuracy):")
            print(f"    [{v['lower']:.2f}%, {v['upper']:.2f}%]")
        else:
            print(f"\n  {k}:")
            for field, val in v.items():
                print(f"    {field}: {val}")


# ------------------------------------------------------------------
# Cross-dataset transfer evaluation
# ------------------------------------------------------------------

def evaluate_transfer(
    source_dataset: str = "field_in",
    target_dataset: str = "plantvillage",
    arch: str = "vit_b16",
    condition: str = "A2s",
    device: Optional[torch.device] = None,
) -> Dict[str, float]:
    """
    Load best checkpoint trained on source_dataset and evaluate
    on full target_dataset (no fine-tuning).

    Paper Sec. V-F: trained on Field-IN; evaluated on PlantVillage.
    The transfer model was trained exclusively on Field-IN;
    no PlantVillage images appeared in its training set.
    """
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Use the best fold checkpoint (fold 01 by default for transfer)
    ckpt_path = (
        Path(C.CHECKPOINT_DIR) / source_dataset / condition / arch
        / "fold_01_best.pt"
    )
    if not ckpt_path.exists():
        print(f"  [transfer] Checkpoint not found: {ckpt_path}")
        return {}

    model = build_model(arch).to(device)
    model.load_state_dict(torch.load(ckpt_path, map_location=device))
    model.eval()

    target_root = (
        C.PLANTVILLAGE_ROOT if target_dataset == "plantvillage"
        else C.FIELDIN_ROOT
    )
    target_ds = LeafDataset(root=target_root, transform=get_base_transform())
    loader    = DataLoader(
        target_ds, batch_size=64, shuffle=False, num_workers=4, pin_memory=True
    )

    probs, true_labels = evaluate(model, loader, device)
    metrics = compute_all_metrics(probs, true_labels)

    print(f"\n  [Transfer] {source_dataset} → {target_dataset} | {arch} | {condition}")
    print(f"  Accuracy : {metrics['accuracy']:.2f}%")
    print(f"  AUC      : {metrics['auc']:.4f}")
    print(f"  F1       : {metrics['f1']:.4f}")
    print(f"  ECE      : {metrics['ece']:.4f}")
    return metrics


# ------------------------------------------------------------------
# Grad-CAM implementation
# ------------------------------------------------------------------

class GradCAM:
    """
    Gradient-weighted Class Activation Mapping for ViT-B/16 and ResNet-50.
    Grad-CAM heatmaps binarised at 50% of max value (paper Sec. V-I).
    """

    def __init__(self, model: nn.Module, arch: str) -> None:
        self.model   = model
        self.arch    = arch
        self._feats  = None
        self._grads  = None
        self._handle_f = None
        self._handle_b = None
        self._register()

    def _register(self) -> None:
        if self.arch == "resnet50":
            target = self.model.layer4[-1]
        else:  # vit_b16
            target = self.model.blocks[-1].norm1

        def fwd_hook(module, inp, out):
            self._feats = out.detach()

        def bwd_hook(module, grad_in, grad_out):
            self._grads = grad_out[0].detach()

        self._handle_f = target.register_forward_hook(fwd_hook)
        self._handle_b = target.register_full_backward_hook(bwd_hook)

    def generate(
        self,
        img_tensor: torch.Tensor,
        class_idx: Optional[int] = None,
    ) -> np.ndarray:
        """
        Generate Grad-CAM heatmap.

        Returns
        -------
        heatmap : np.ndarray, shape (H, W), values in [0, 1]
        """
        self.model.eval()
        img_tensor = img_tensor.unsqueeze(0).to(next(self.model.parameters()).device)
        img_tensor.requires_grad_(True)

        logits = self.model(img_tensor)
        if class_idx is None:
            class_idx = logits.argmax(dim=1).item()

        self.model.zero_grad()
        logits[0, class_idx].backward()

        grads = self._grads
        feats = self._feats

        if self.arch == "resnet50":
            # GAP over spatial dims
            weights = grads.mean(dim=[2, 3], keepdim=True)  # (1, C, 1, 1)
            cam     = (weights * feats).sum(dim=1).squeeze()
        else:
            # ViT: feats shape (1, seq_len, dim)
            # Average attention weights over sequence
            grads_avg = grads.mean(dim=2)  # (1, seq_len)
            feats_avg = feats.mean(dim=2)  # (1, seq_len)
            cam_seq   = (grads_avg * feats_avg).squeeze()
            # Reshape to spatial: skip [CLS] token
            n_patches = cam_seq.shape[0] - 1
            side      = int(n_patches ** 0.5)
            cam       = cam_seq[1:].reshape(side, side)

        cam = cam.cpu().numpy()
        cam = np.maximum(cam, 0)
        if cam.max() > 0:
            cam = cam / cam.max()
        # Resize to original image size
        cam_resized = np.array(
            Image.fromarray((cam * 255).astype(np.uint8)).resize(
                (C.IMG_SIZE, C.IMG_SIZE), Image.BILINEAR
            )
        ).astype(float) / 255.0
        return cam_resized

    def remove_hooks(self) -> None:
        self._handle_f.remove()
        self._handle_b.remove()


def compute_iou_with_mask(
    heatmap: np.ndarray,
    annotation_mask: np.ndarray,
    threshold: float = C.GRADCAM_BINARISE_THRESH,
) -> float:
    """
    Compute IoU between binarised Grad-CAM heatmap and annotated mask.
    Paper Sec. V-I: binarise at 50% of max activation.

    Parameters
    ----------
    heatmap : np.ndarray, shape (H, W), values in [0, 1]
    annotation_mask : np.ndarray, shape (H, W), dtype bool
    threshold : float

    Returns
    -------
    iou : float
    """
    binary_cam = heatmap >= threshold
    intersection = (binary_cam & annotation_mask).sum()
    union        = (binary_cam | annotation_mask).sum()
    if union == 0:
        return 0.0
    return float(intersection / union)


# ------------------------------------------------------------------
# CLI
# ------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="RD-Aug: Post-training evaluation"
    )
    parser.add_argument("--dataset",   choices=ALL_DATASETS + ["all"],
                        default="plantvillage")
    parser.add_argument("--arch",      choices=ALL_ARCHS + ["all"],
                        default="vit_b16")
    parser.add_argument("--transfer",  action="store_true",
                        help="Run cross-dataset transfer evaluation")
    parser.add_argument("--stats",     action="store_true", default=True,
                        help="Print statistical tests")
    args = parser.parse_args()

    datasets = ALL_DATASETS if args.dataset == "all" else [args.dataset]
    archs    = ALL_ARCHS    if args.arch    == "all" else [args.arch]

    for ds in datasets:
        for arch in archs:
            print_ablation_table(ds, arch)
            if args.stats:
                print_statistics(ds, arch)

    if args.transfer:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        transfer_conditions = ["A0", "A1", "A3", "A6", "A2", "A2s"]
        print(f"\n{'='*72}")
        print(f"  Cross-Dataset Transfer: Field-IN → PlantVillage (ViT-B/16)")
        print(f"{'='*72}")
        for cond in transfer_conditions:
            evaluate_transfer(
                source_dataset="field_in",
                target_dataset="plantvillage",
                arch="vit_b16",
                condition=cond,
                device=device,
            )


if __name__ == "__main__":
    main()
