# RD-Aug: Reaction-Diffusion-Inspired Synthetic Augmentation

Complete Python implementation for the paper  
**"RD-Aug: A Reaction–Diffusion-Inspired Synthetic Augmentation Framework for Potato Blight Stage Classification"**  
Target: IEEE Transactions on AgriFood Electronics (TAFE)

---

## Repository Structure

```
rdaug/
├── config.py          # All paper parameters — single source of truth
├── download_data.py   # Downloads PlantVillage from Kaggle
├── rd_aug.py          # Fisher-KPP PDE solver + lesion generation (Algorithm 1)
├── dataset.py         # PyTorch Datasets + DataLoader factory (Algorithm 2)
├── train.py           # 10-fold CV training for all 8 conditions
├── metrics.py         # Accuracy, AUC, F1, ECE, Wilcoxon, permutation test, CI
├── morphology.py      # Morphological validation — Table II descriptors
├── evaluate.py        # Ablation tables, statistics, transfer, Grad-CAM IoU
├── run_all.py         # Single entry point for the full pipeline
└── requirements.txt   # All dependencies with pinned versions
```

---

## Setup

```bash
# 1. Create environment
python -m venv venv && source venv/bin/activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Kaggle credentials (for PlantVillage download)
#    Place kaggle.json at ~/.kaggle/kaggle.json
#    chmod 600 ~/.kaggle/kaggle.json
```

---

## Datasets

### PlantVillage (Primary — Public)
Downloaded automatically:
```bash
python download_data.py
```
Expected layout after download:
```
data/plantvillage/
    early_blight/    # 1000 images
    late_blight/     # 1000 images
    healthy/         # 152 images
```

### Field-IN (Supplementary — Private)
Contact the corresponding author or Zenodo deposit.  
Place manually at:
```
data/field_in/
    early_blight/    # 400 images
    late_blight/     # 400 images
    healthy/         # 400 images
```

---

## Quick Start

```bash
# Sanity check (2 folds, A2s, PlantVillage, ViT-B/16)
python run_all.py --quick

# Single condition
python run_all.py --dataset plantvillage --condition A2s --arch vit_b16

# Full ablation (all 8 conditions × 2 archs × 2 datasets, ~12-24h on A100)
python run_all.py --all
```

---

## Augmentation Conditions

| ID   | Description                                    | synth_loader shuffle |
|------|------------------------------------------------|----------------------|
| A0   | Real only                                      | —                    |
| A1   | +1800 standard augmentations                   | —                    |
| A4   | +1800 MixUp (Beta(0.4, 0.4))                  | —                    |
| A5   | +1800 CutMix (Beta(1.0, 1.0))                 | —                    |
| A6   | +1800 RandAugment (N=2, M=9)                  | —                    |
| A3   | +1800 KPP frames, **shuffle=True** (control)   | True                 |
| A2   | +1800 KPP frames, **shuffle=False**, fixed nuc.| False                |
| **A2s** | +1800 KPP frames, **shuffle=False**, stoch. nuc. (**proposed**) | False |

---

## PDE Parameters (Paper Sec. III-A)

| Parameter | Value | Description |
|-----------|-------|-------------|
| D         | 0.25  | Diffusion coefficient |
| r         | 1.5   | Intrinsic growth rate |
| K         | 1.0   | Carrying capacity |
| M         | 3     | Number of inoculation nuclei |
| σ         | 8 px  | Gaussian inoculum width |
| T         | 6     | Output frames (snapshots) |
| N_sub     | 70    | Euler sub-steps per frame |
| Δt        | 0.05  | Time step (CFL limit = 1.0; 20× margin) |
| α         | 0.7   | Alpha-blending weight |

Wave speed: v* = 2√(Dr) ≈ 1.22 px/time-unit  
Time per frame: 70 × 0.05 = 3.5 time-units  
Radial advance per frame: ≈ 4.3 px  

---

## Training Hyperparameters (Paper Sec. V-B)

| Parameter     | Value |
|---------------|-------|
| Architecture  | ResNet-50, ViT-B/16 (timm, ImageNet-1K pretrained) |
| Optimiser     | AdamW (lr=1e-4, wd=1e-4, β₁=0.9, β₂=0.999) |
| Batch size    | 32 |
| Epochs        | 100 |
| LR schedule   | Cosine annealing |
| CV            | 10-fold stratified, seed=42 |

---

## Evaluation

```bash
# Print all ablation tables
python evaluate.py --dataset plantvillage

# Cross-dataset transfer table
python evaluate.py --transfer

# All tables + transfer
python evaluate.py --dataset all --transfer
```

---

## Running Individual Modules

```bash
# Test PDE solver
python rd_aug.py

# Test metrics
python metrics.py

# Test morphological segmentation
python morphology.py
```

---

## Expected Results (Paper Tables III/IV)

**PlantVillage | ViT-B/16**

| Condition | Acc    | AUC    | F1     | ECE    |
|-----------|--------|--------|--------|--------|
| A0        | 91.3%  | 0.8800 | 0.8400 | 0.0810 |
| A6        | 96.1%  | 0.9400 | 0.9500 | 0.0450 |
| A3        | 95.6%  | 0.9400 | 0.9500 | 0.0460 |
| A2        | 97.2%  | 0.9600 | 0.9700 | 0.0310 |
| **A2s**   | **97.5%** | **0.9600** | **0.9700** | **0.0290** |

---

## Citation

```bibtex
@article{bashishtha2025rdaug,
  title   = {{RD-Aug}: A Reaction--Diffusion-Inspired Synthetic Augmentation
             Framework for Potato Blight Stage Classification},
  author  = {Bashishtha, T. K. and Singh, V. P. and Dubey, Rishav},
  journal = {IEEE Transactions on AgriFood Electronics},
  year    = {2025},
  note    = {Under review}
}
```
