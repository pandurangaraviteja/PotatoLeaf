"""
run_all.py
==========
Single entry point for the complete RD-Aug pipeline.

Steps
-----
  1. Download PlantVillage (requires Kaggle API credentials).
  2. Generate synthetic datasets for A2, A2s, A3 conditions.
  3. Run 10-fold CV for all 8 conditions × 2 architectures × 2 datasets.
  4. Run morphological validation (Table II).
  5. Print all ablation tables and statistical tests.
  6. Run cross-dataset transfer experiments (Table VI).

Usage
-----
    # Full pipeline (GPU recommended, ~12-24h for all conditions)
    python run_all.py --all

    # Quick sanity run: A2s on PlantVillage, ViT-B/16, 2 folds
    python run_all.py --quick

    # Single condition
    python run_all.py --dataset plantvillage --condition A2s --arch vit_b16
"""

from __future__ import annotations

import argparse
import os
import random
import time
from pathlib import Path

import numpy as np
import torch

import config as C
from download_data import check_fieldin, download_plantvillage
from evaluate import evaluate_transfer, print_ablation_table, print_statistics
from morphology import full_morphological_comparison
from rd_aug import generate_synthetic_dataset
from train import ALL_ARCHS, ALL_CONDITIONS, ALL_DATASETS, run_cv, set_seed


def main() -> None:
    parser = argparse.ArgumentParser(description="RD-Aug full pipeline")
    parser.add_argument("--all",       action="store_true",
                        help="Run complete pipeline for all conditions/archs/datasets")
    parser.add_argument("--quick",     action="store_true",
                        help="Quick test: A2s, PlantVillage, ViT-B/16, 2 folds")
    parser.add_argument("--dataset",   choices=ALL_DATASETS + ["all"],
                        default="plantvillage")
    parser.add_argument("--condition", choices=ALL_CONDITIONS + ["all"],
                        default="A2s")
    parser.add_argument("--arch",      choices=ALL_ARCHS + ["all"],
                        default="vit_b16")
    parser.add_argument("--skip_download",  action="store_true")
    parser.add_argument("--skip_morph",     action="store_true")
    parser.add_argument("--skip_transfer",  action="store_true")
    parser.add_argument("--gpu",       type=int, default=0)
    args = parser.parse_args()

    # Create output directories
    for d in [C.CHECKPOINT_DIR, C.RESULTS_DIR, C.FIGURES_DIR,
              C.LOGS_DIR, C.SYNTHETIC_DIR]:
        Path(d).mkdir(parents=True, exist_ok=True)

    set_seed(C.SEED)
    device = torch.device(
        f"cuda:{args.gpu}" if torch.cuda.is_available() else "cpu"
    )
    print(f"\n{'='*60}")
    print(f"  RD-Aug Pipeline  |  device={device}  |  seed={C.SEED}")
    print(f"{'='*60}")

    # ------------------------------------------------------------------
    # Step 1: Data
    # ------------------------------------------------------------------
    if not args.skip_download:
        print("\n[Step 1] Downloading / verifying datasets ...")
        download_plantvillage()
        check_fieldin()
    else:
        print("\n[Step 1] Skipping download (--skip_download).")

    # ------------------------------------------------------------------
    # Step 2: Training
    # ------------------------------------------------------------------
    print("\n[Step 2] Training ...")

    if args.quick:
        print("  Quick mode: A2s | plantvillage | vit_b16 | 2 folds")
        # Monkey-patch N_FOLDS for quick run
        import config as _c
        _c.N_FOLDS = 2
        run_cv("plantvillage", "A2s", "vit_b16", device)
        _c.N_FOLDS = C.N_FOLDS  # restore
    elif args.all:
        t0 = time.time()
        for ds in ALL_DATASETS:
            for cond in ALL_CONDITIONS:
                for arch in ALL_ARCHS:
                    run_cv(ds, cond, arch, device)
        elapsed = time.time() - t0
        print(f"\n  All training complete in {elapsed/3600:.1f}h")
    else:
        datasets   = ALL_DATASETS   if args.dataset   == "all" else [args.dataset]
        conditions = ALL_CONDITIONS if args.condition  == "all" else [args.condition]
        archs      = ALL_ARCHS      if args.arch       == "all" else [args.arch]
        for ds in datasets:
            for cond in conditions:
                for arch in archs:
                    run_cv(ds, cond, arch, device)

    # ------------------------------------------------------------------
    # Step 3: Morphological Validation
    # ------------------------------------------------------------------
    if not args.skip_morph:
        print("\n[Step 3] Morphological validation (Table II) ...")
        _run_morphological_validation(device)
    else:
        print("\n[Step 3] Skipping morphological validation (--skip_morph).")

    # ------------------------------------------------------------------
    # Step 4: Evaluation tables + statistics
    # ------------------------------------------------------------------
    print("\n[Step 4] Evaluation tables ...")
    datasets = ALL_DATASETS if (args.all or args.dataset == "all") else [args.dataset]
    archs    = ALL_ARCHS    if (args.all or args.arch    == "all") else [args.arch]
    for ds in datasets:
        for arch in archs:
            print_ablation_table(ds, arch)
            print_statistics(ds, arch)

    # ------------------------------------------------------------------
    # Step 5: Cross-dataset transfer
    # ------------------------------------------------------------------
    if not args.skip_transfer and not args.quick:
        print("\n[Step 5] Cross-dataset transfer (Table VI) ...")
        conditions_transfer = (
            ALL_CONDITIONS if args.all else
            ["A0", "A1", "A3", "A6", "A2", "A2s"]
        )
        for cond in conditions_transfer:
            evaluate_transfer(
                source_dataset="field_in",
                target_dataset="plantvillage",
                arch="vit_b16",
                condition=cond,
                device=device,
            )
    else:
        print("\n[Step 5] Skipping transfer (quick mode or --skip_transfer).")

    print("\n[run_all] Pipeline complete.")
    print(f"  Results   : {C.RESULTS_DIR}/")
    print(f"  Checkpoints: {C.CHECKPOINT_DIR}/")


def _run_morphological_validation(device: torch.device) -> None:
    """
    Generate a small batch of synthetic images and run morphological
    comparison against PlantVillage images.
    """
    from dataset import LeafDataset
    from rd_aug import generate_synthetic_dataset

    pv_root = C.PLANTVILLAGE_ROOT
    pv_ds   = LeafDataset(root=pv_root)
    if len(pv_ds) == 0:
        print("  [morph] No PlantVillage images found; skipping.")
        return

    # Load ~200 real lesion images (early + late blight)
    real_images = []
    for path, label in pv_ds.samples:
        if label in (C.LABEL_EARLY_BLIGHT, C.LABEL_LATE_BLIGHT):
            from PIL import Image as _PIL
            img = np.array(_PIL.open(path).convert("RGB").resize(
                (C.IMG_SIZE, C.IMG_SIZE)
            ))
            real_images.append(img)
        if len(real_images) >= 200:
            break

    # Load healthy images for backgrounds
    healthy_images = []
    for path, label in pv_ds.samples:
        if label == C.LABEL_HEALTHY:
            from PIL import Image as _PIL
            img = np.array(_PIL.open(path).convert("RGB").resize(
                (C.IMG_SIZE, C.IMG_SIZE)
            ))
            healthy_images.append(img)

    if not healthy_images:
        healthy_images = [np.full((C.IMG_SIZE, C.IMG_SIZE, 3),
                                   [80, 120, 60], dtype=np.uint8)]

    # Generate 300 synthetic images for comparison
    synth_images, _ = generate_synthetic_dataset(
        healthy_images=healthy_images,
        n_per_class=150,   # 150 early + 150 late = 300
        stochastic=True,
        shuffle_frames=False,
        seed=C.SEED,
    )

    results = full_morphological_comparison(
        real_images=real_images,
        synth_images=synth_images,
        compute_fid_flag=True,
    )

    # Save
    import json
    out_path = Path(C.RESULTS_DIR) / "morphological_validation.json"
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"  [morph] Results saved to {out_path}")


if __name__ == "__main__":
    main()
