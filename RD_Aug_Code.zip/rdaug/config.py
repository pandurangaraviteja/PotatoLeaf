"""
config.py
=========
Single source of truth for every parameter stated in the paper.
All other modules import from here; nothing is hard-coded elsewhere.
"""

# ------------------------------------------------------------------
# Reproducibility
# ------------------------------------------------------------------
SEED = 42

# ------------------------------------------------------------------
# Dataset paths  (edit to match your local layout)
# ------------------------------------------------------------------
# PlantVillage potato subset — primary dataset
# Expected structure:
#   PLANTVILLAGE_ROOT/
#       Potato___Early_blight/   (1000 images)
#       Potato___Late_blight/    (1000 images)
#       Potato___healthy/        (152  images)
PLANTVILLAGE_ROOT = "data/plantvillage"

# Field-IN — supplementary field dataset
# Expected structure:
#   FIELDIN_ROOT/
#       early_blight/  (400 images)
#       late_blight/   (400 images)
#       healthy/       (400 images)
FIELDIN_ROOT = "data/field_in"

# Where synthetic images are written
SYNTHETIC_DIR = "data/synthetic"

# ------------------------------------------------------------------
# Image dimensions
# ------------------------------------------------------------------
IMG_SIZE = 224          # resize all images to 224×224 (paper Sec. V-B)

# ------------------------------------------------------------------
# Class mapping
# ------------------------------------------------------------------
CLASS_NAMES  = ["healthy", "early_blight", "late_blight"]
NUM_CLASSES  = 3
LABEL_HEALTHY      = 0
LABEL_EARLY_BLIGHT = 1
LABEL_LATE_BLIGHT  = 2

# ------------------------------------------------------------------
# RD-Aug PDE parameters (paper Eq. 1 and Sec. III-A)
# ------------------------------------------------------------------
RD_D      = 0.25    # diffusion coefficient
RD_R      = 1.5     # intrinsic growth rate
RD_K      = 1.0     # carrying capacity
RD_M      = 3       # number of inoculation nuclei
RD_SIGMA  = 8.0     # Gaussian inoculum width (px)
RD_T      = 6       # number of output frames (snapshots)
RD_NSUB   = 70      # forward-Euler sub-steps per frame
RD_DT     = 0.05    # Euler time step  (CFL limit = h²/4D = 1.0; 20× margin)
RD_ALPHA  = 0.7     # alpha-blending weight for compositing

# Stage label threshold: mean C < 0.3K → early blight; ≥ 0.3K → late blight
RD_THRESH = 0.3     # fraction of K

# Frames that map to early blight (0-indexed: frames 0,1) and late blight (2-5)
EARLY_FRAMES = [0, 1]
LATE_FRAMES  = [2, 3, 4, 5]

# Synthetic images to generate per class
SYNTH_PER_CLASS = 600   # → 1800 total

# ------------------------------------------------------------------
# Augmentation hyperparameters
# ------------------------------------------------------------------
MIXUP_ALPHA  = 0.4   # Beta(alpha, alpha) for MixUp  (paper Sec. V-D)
CUTMIX_ALPHA = 1.0   # Beta(alpha, alpha) for CutMix
RANDAUG_N    = 2     # RandAugment: number of operations
RANDAUG_M    = 9     # RandAugment: magnitude

# Standard augmentation params (A1)
STD_CROP_SCALE   = (0.8, 1.0)   # ±20% crop → scale range [0.8, 1.0]
STD_JITTER_B     = 0.2          # brightness
STD_JITTER_C     = 0.2          # contrast
STD_JITTER_S     = 0.1          # saturation

# ------------------------------------------------------------------
# Training hyperparameters (paper Sec. V-B)
# ------------------------------------------------------------------
BATCH_SIZE    = 32
EPOCHS        = 100
LR            = 1e-4
WEIGHT_DECAY  = 1e-4
BETA1         = 0.9
BETA2         = 0.999
N_FOLDS       = 10              # 10-fold stratified CV

# ------------------------------------------------------------------
# ECE evaluation (paper Sec. V-B)
# ------------------------------------------------------------------
ECE_BINS = 15                   # equal-width confidence bins; raw softmax

# ------------------------------------------------------------------
# Morphological validation (paper Sec. V-C)
# ------------------------------------------------------------------
MORPH_OTSU_CHANNEL   = "S"     # HSV saturation channel for Otsu threshold
MORPH_CLOSE_RADIUS   = 3       # morphological closing disk radius (px)
MORPH_ERODE_RADIUS   = 5       # erosion disk radius for edge thickness (px)
MORPH_MIN_PATCH_PX   = 10      # discard patches smaller than 10×10 px

# FID feature extractor
FID_FEATURE_DIM = 2048          # ResNet-50 avgpool (paper Sec. V-C)

# ------------------------------------------------------------------
# Grad-CAM (paper Sec. V-I)
# ------------------------------------------------------------------
GRADCAM_BINARISE_THRESH = 0.5  # fraction of max activation for binarisation

# ------------------------------------------------------------------
# Derived / verification constants (paper Sec. III-A)
# ------------------------------------------------------------------
WAVE_SPEED = 2 * (RD_D * RD_R) ** 0.5          # ≈ 1.22 px/time-unit
TIME_PER_FRAME = RD_NSUB * RD_DT                # = 3.5 time-units
RADIAL_ADVANCE_PER_FRAME = WAVE_SPEED * TIME_PER_FRAME  # ≈ 4.27 px

assert RD_DT <= 1.0 / (4 * RD_D), "CFL stability violated"

# ------------------------------------------------------------------
# Output directories
# ------------------------------------------------------------------
CHECKPOINT_DIR = "checkpoints"
RESULTS_DIR    = "results"
FIGURES_DIR    = "figures"
LOGS_DIR       = "logs"
