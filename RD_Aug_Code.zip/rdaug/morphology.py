"""
morphology.py
=============
Extended morphological validation of synthetic lesions (paper Sec. V-C).

Implements all nine descriptors from Table II:
  Biological (7): lesion area, circularity, eccentricity,
                  mean R channel, mean G channel,
                  LBP texture uniformity, necrotic edge thickness
  Perceptual (2): SSIM, FID (ResNet-50 avgpool 2048-d)

Segmentation protocol (paper Sec. V-C):
  - Otsu threshold on HSV saturation channel
  - Morphological closing, disk radius 3 px
  - Discard patches < 10×10 px
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
from PIL import Image
from skimage.feature import local_binary_pattern
from skimage.filters import threshold_otsu
from skimage.measure import label as sk_label, regionprops
from skimage.morphology import binary_closing, binary_erosion, disk
from skimage.metrics import structural_similarity as ssim_fn

import config as C
from metrics import mann_whitney_u


# ------------------------------------------------------------------
# Segmentation
# ------------------------------------------------------------------

def segment_lesion(
    img_rgb: np.ndarray,
    close_radius: int = C.MORPH_CLOSE_RADIUS,
    min_px: int = C.MORPH_MIN_PATCH_PX,
) -> Optional[np.ndarray]:
    """
    Extract binary lesion mask using Otsu on HSV-S channel.

    Paper Sec. V-C:
      1. Convert to HSV.
      2. Apply Otsu threshold to saturation channel.
      3. Morphological closing (disk radius 3 px).
      4. Discard if patch < min_px × min_px.

    Returns
    -------
    mask : np.ndarray, shape (H, W), dtype bool, or None if too small.
    """
    hsv = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2HSV)
    S   = hsv[:, :, 1].astype(float) / 255.0

    thresh = threshold_otsu(S)
    mask   = S > thresh
    mask   = binary_closing(mask, footprint=disk(close_radius))

    # Discard trivially small masks
    if mask.sum() < min_px * min_px:
        return None
    return mask


# ------------------------------------------------------------------
# Individual descriptors
# ------------------------------------------------------------------

def lesion_area_fraction(mask: np.ndarray) -> float:
    """Lesion area as percentage of leaf surface (paper Table II)."""
    H, W = mask.shape
    return float(mask.sum() / (H * W) * 100.0)


def circularity(mask: np.ndarray) -> float:
    """
    Circularity = 4π·Area / Perimeter².
    Uses skimage regionprops for sub-pixel accuracy.
    """
    lbl = sk_label(mask)
    props = regionprops(lbl)
    if not props:
        return 0.0
    # Use the largest region
    largest = max(props, key=lambda p: p.area)
    perim = largest.perimeter
    if perim < 1e-6:
        return 0.0
    return float(4.0 * np.pi * largest.area / (perim ** 2))


def eccentricity(mask: np.ndarray) -> float:
    """Eccentricity of the largest lesion region (0 = circle, 1 = line)."""
    lbl = sk_label(mask)
    props = regionprops(lbl)
    if not props:
        return 0.0
    largest = max(props, key=lambda p: p.area)
    return float(largest.eccentricity)


def mean_channel(img_rgb: np.ndarray, mask: np.ndarray, channel: int) -> float:
    """
    Mean pixel value in the specified RGB channel within the lesion mask.
    Normalised to [0, 1].
    channel: 0=R, 1=G, 2=B.
    """
    ch = img_rgb[:, :, channel].astype(float) / 255.0
    if mask.sum() == 0:
        return 0.0
    return float(ch[mask].mean())


def lbp_uniformity(
    img_rgb: np.ndarray,
    mask: np.ndarray,
    P: int = 8,
    R: float = 1.0,
) -> float:
    """
    LBP texture uniformity within the lesion mask.

    Uses the rotation-invariant uniform LBP descriptor
    (Ojala et al. 2002, cited in paper Sec. V-C).

    P: number of neighbours. R: radius.
    Returns fraction of uniform (u2) patterns.
    """
    gray = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2GRAY)
    lbp  = local_binary_pattern(gray, P=P, R=R, method="uniform")
    if mask.sum() == 0:
        return 0.0
    lbp_in_mask = lbp[mask]
    # Uniform patterns have LBP value in [0, P]; fraction of such patterns
    uniform_frac = float((lbp_in_mask <= P).mean())
    return uniform_frac


def necrotic_edge_thickness(mask: np.ndarray, erode_radius: int = C.MORPH_ERODE_RADIUS) -> float:
    """
    Necrotic edge thickness (px).

    Paper Eq. (8): E = M \setminus erode(M, r=5)
    Edge thickness = area(E) / perimeter(M) per patch, then averaged.

    Returns
    -------
    float : mean edge thickness in pixels, or 0.0 if mask is empty.
    """
    if mask.sum() == 0:
        return 0.0

    eroded    = binary_erosion(mask, footprint=disk(erode_radius))
    edge_mask = mask & (~eroded)
    edge_area = float(edge_mask.sum())

    # Perimeter from regionprops
    lbl   = sk_label(mask)
    props = regionprops(lbl)
    if not props:
        return 0.0
    largest = max(props, key=lambda p: p.area)
    perim   = largest.perimeter
    if perim < 1e-6:
        return 0.0

    return edge_area / perim


def compute_ssim(img_a: np.ndarray, img_b: np.ndarray) -> float:
    """SSIM between two RGB images. Paper Sec. V-C."""
    # skimage SSIM expects float images in [0,1]
    a = img_a.astype(float) / 255.0
    b = img_b.astype(float) / 255.0
    return float(ssim_fn(a, b, channel_axis=2, data_range=1.0))


# ------------------------------------------------------------------
# FID computation
# ------------------------------------------------------------------

def compute_fid(
    features_real: np.ndarray,
    features_synth: np.ndarray,
) -> float:
    """
    Fréchet Inception Distance between real and synthetic feature sets.

    Paper: ResNet-50 avgpool (2048-d) features on all 1012 patches.
    Follows Heusel et al. (2017) protocol.

    Parameters
    ----------
    features_real  : np.ndarray, shape (N_real, 2048)
    features_synth : np.ndarray, shape (N_synth, 2048)

    Returns
    -------
    fid : float
    """
    mu_r  = features_real.mean(axis=0)
    mu_s  = features_synth.mean(axis=0)
    sigma_r = np.cov(features_real,  rowvar=False)
    sigma_s = np.cov(features_synth, rowvar=False)

    diff = mu_r - mu_s
    # Matrix square root via eigendecomposition (stable for large matrices)
    cov_mean = _sqrtm(sigma_r @ sigma_s)

    fid = float(diff @ diff + np.trace(sigma_r + sigma_s - 2.0 * cov_mean))
    return fid


def _sqrtm(A: np.ndarray) -> np.ndarray:
    """Matrix square root via eigendecomposition."""
    vals, vecs = np.linalg.eigh(A)
    vals = np.maximum(vals, 0.0)
    return vecs @ np.diag(np.sqrt(vals)) @ vecs.T


def extract_resnet50_features(
    images: List[np.ndarray],
    device_str: str = "cuda" if True else "cpu",
    batch_size: int = 32,
) -> np.ndarray:
    """
    Extract ResNet-50 avgpool (2048-d) features for FID computation.
    Paper Sec. V-C.
    """
    import torch
    import timm
    from torchvision import transforms

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model  = timm.create_model("resnet50", pretrained=True, num_classes=0)
    model  = model.to(device).eval()

    transform = transforms.Compose([
        transforms.Resize((C.IMG_SIZE, C.IMG_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
    ])

    all_feats = []
    with torch.no_grad():
        for i in range(0, len(images), batch_size):
            batch_pil = [Image.fromarray(img) for img in images[i:i+batch_size]]
            tensors   = torch.stack([transform(p) for p in batch_pil]).to(device)
            feats     = model(tensors).cpu().numpy()
            all_feats.append(feats)

    return np.concatenate(all_feats, axis=0)


# ------------------------------------------------------------------
# Full morphological comparison pipeline
# ------------------------------------------------------------------

def full_morphological_comparison(
    real_images: List[np.ndarray],
    synth_images: List[np.ndarray],
    compute_fid_flag: bool = True,
) -> Dict:
    """
    Compute all nine descriptors and Mann-Whitney U tests.
    Reproduces Table II of the paper.

    Parameters
    ----------
    real_images  : list of np.ndarray, shape (H, W, 3), dtype uint8
    synth_images : list of np.ndarray, shape (H, W, 3), dtype uint8
    compute_fid_flag : bool
        Set False to skip FID (slow; requires GPU).

    Returns
    -------
    dict with keys matching paper Table II descriptors
    """
    print("[morphology] Segmenting real lesion patches ...")
    real_masks  = _segment_batch(real_images)
    print("[morphology] Segmenting synthetic lesion patches ...")
    synth_masks = _segment_batch(synth_images)

    real_valid  = [(img, m) for img, m in zip(real_images,  real_masks)  if m is not None]
    synth_valid = [(img, m) for img, m in zip(synth_images, synth_masks) if m is not None]

    print(f"  Real patches  : {len(real_valid)} valid (discarded {len(real_images) - len(real_valid)})")
    print(f"  Synth patches : {len(synth_valid)} valid")

    # ---- Compute all descriptors ----
    descriptors = {
        "lesion_area":      ([], []),
        "circularity":      ([], []),
        "eccentricity":     ([], []),
        "mean_R":           ([], []),
        "mean_G":           ([], []),
        "lbp_uniformity":   ([], []),
        "edge_thickness":   ([], []),
    }

    for img, mask in real_valid:
        descriptors["lesion_area"][0].append(lesion_area_fraction(mask))
        descriptors["circularity"][0].append(circularity(mask))
        descriptors["eccentricity"][0].append(eccentricity(mask))
        descriptors["mean_R"][0].append(mean_channel(img, mask, 0))
        descriptors["mean_G"][0].append(mean_channel(img, mask, 1))
        descriptors["lbp_uniformity"][0].append(lbp_uniformity(img, mask))
        descriptors["edge_thickness"][0].append(necrotic_edge_thickness(mask))

    for img, mask in synth_valid:
        descriptors["lesion_area"][1].append(lesion_area_fraction(mask))
        descriptors["circularity"][1].append(circularity(mask))
        descriptors["eccentricity"][1].append(eccentricity(mask))
        descriptors["mean_R"][1].append(mean_channel(img, mask, 0))
        descriptors["mean_G"][1].append(mean_channel(img, mask, 1))
        descriptors["lbp_uniformity"][1].append(lbp_uniformity(img, mask))
        descriptors["edge_thickness"][1].append(necrotic_edge_thickness(mask))

    # ---- Statistical tests ----
    results = {}
    print("\n  Descriptor           Real mean±std    Synth mean±std    p-value")
    print("  " + "-" * 65)

    for name, (real_vals, synth_vals) in descriptors.items():
        r_arr = np.array(real_vals)
        s_arr = np.array(synth_vals)
        _, p  = mann_whitney_u(r_arr, s_arr)
        results[name] = {
            "real_mean":  float(r_arr.mean()),
            "real_std":   float(r_arr.std()),
            "synth_mean": float(s_arr.mean()),
            "synth_std":  float(s_arr.std()),
            "p_value":    float(p),
            "significant": p < 0.05,
        }
        print(
            f"  {name:<20} {r_arr.mean():.3f}±{r_arr.std():.3f}   "
            f"{s_arr.mean():.3f}±{s_arr.std():.3f}   "
            f"p={p:.3f} {'*' if p < 0.05 else ''}"
        )

    # ---- SSIM ----
    real_mean_img = _mean_image([img for img, _ in real_valid])
    ssim_vals = [
        compute_ssim(img, real_mean_img)
        for img, _ in synth_valid
    ]
    results["ssim"] = {
        "synth_mean": float(np.mean(ssim_vals)),
        "synth_std":  float(np.std(ssim_vals)),
        "note": "Perceptual; p-value not applicable",
    }
    print(f"  {'ssim':<20} 1.000 (ref.)     "
          f"{np.mean(ssim_vals):.3f}±{np.std(ssim_vals):.3f}   n/a")

    # ---- FID ----
    if compute_fid_flag:
        print("\n  Computing FID (ResNet-50 avgpool features) ...")
        all_images = [img for img, _ in real_valid] + [img for img, _ in synth_valid]
        all_feats  = extract_resnet50_features(all_images)
        n_real     = len(real_valid)
        fid_score  = compute_fid(all_feats[:n_real], all_feats[n_real:])
        results["fid"] = {
            "value": float(fid_score),
            "note": "ResNet-50 avgpool 2048-d; intra-domain; perceptual only",
        }
        print(f"  FID = {fid_score:.2f}")

    return results


def _segment_batch(images: List[np.ndarray]) -> List[Optional[np.ndarray]]:
    return [segment_lesion(img) for img in images]


def _mean_image(images: List[np.ndarray]) -> np.ndarray:
    stacked = np.stack([img.astype(float) for img in images], axis=0)
    return stacked.mean(axis=0).clip(0, 255).astype(np.uint8)


if __name__ == "__main__":
    # Quick sanity check: create a trivial synthetic pair
    rng = np.random.default_rng(42)
    # Simulate a green leaf with a brownish circular lesion
    bg  = np.full((224, 224, 3), [80, 120, 60], dtype=np.uint8)
    img = bg.copy()
    cy, cx, rad = 112, 112, 40
    yy, xx = np.ogrid[:224, :224]
    circle = ((yy - cy)**2 + (xx - cx)**2) <= rad**2
    img[circle, 0] = 140   # reddish-brown lesion
    img[circle, 1] = 90
    img[circle, 2] = 30

    mask = segment_lesion(img)
    if mask is not None:
        print(f"Lesion area: {lesion_area_fraction(mask):.2f}%")
        print(f"Circularity: {circularity(mask):.3f}")
        print(f"Eccentricity: {eccentricity(mask):.3f}")
        print(f"Edge thickness: {necrotic_edge_thickness(mask):.2f} px")
    print("morphology.py self-test passed.")
