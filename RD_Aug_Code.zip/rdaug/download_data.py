"""
download_data.py
================
Downloads and prepares the PlantVillage potato subset from Kaggle.

Usage
-----
    # 1. Install kaggle API and authenticate:
    #    pip install kaggle
    #    Place kaggle.json in ~/.kaggle/kaggle.json  (chmod 600)
    #
    # 2. Run:
    python download_data.py

What it does
------------
- Downloads the PlantVillage dataset from Kaggle
  (dataset: abdallahalidev/plantvillage-dataset)
- Extracts and filters to the three potato classes:
    Potato___Early_blight  → data/plantvillage/early_blight/
    Potato___Late_blight   → data/plantvillage/late_blight/
    Potato___healthy       → data/plantvillage/healthy/
- Verifies image counts match the paper:
    early_blight: 1000 images
    late_blight:  1000 images
    healthy:       152 images
    total:        2152 images

Field-IN
--------
Field-IN is a private dataset deposited on Zenodo.
Contact the corresponding author or place images manually at:
    data/field_in/early_blight/
    data/field_in/late_blight/
    data/field_in/healthy/
Expected counts: 400 images per class (1200 total).
"""

import os
import shutil
import zipfile
from pathlib import Path

import config as C

# ------------------------------------------------------------------
# PlantVillage class folders → our canonical names
# ------------------------------------------------------------------
PV_FOLDER_MAP = {
    "Potato___Early_blight": "early_blight",
    "Potato___Late_blight":  "late_blight",
    "Potato___healthy":      "healthy",
}

EXPECTED_COUNTS = {
    "early_blight": 1000,
    "late_blight":  1000,
    "healthy":      152,
}


def download_plantvillage(dest_root: str = C.PLANTVILLAGE_ROOT) -> None:
    """Download and extract PlantVillage potato subset via Kaggle API."""
    dest_root = Path(dest_root)
    dest_root.mkdir(parents=True, exist_ok=True)

    # Check if already prepared
    if _verify_counts(dest_root, silent=True):
        print("[download_data] PlantVillage already prepared. Skipping download.")
        return

    print("[download_data] Downloading PlantVillage from Kaggle ...")
    tmp_dir = Path("_tmp_pv_download")
    tmp_dir.mkdir(exist_ok=True)

    os.system(
        f"kaggle datasets download -d abdallahalidev/plantvillage-dataset "
        f"-p {tmp_dir} --unzip"
    )

    # Locate the segmented folder (the colour images)
    # Kaggle layout: plantvillage dataset/color/Potato___*/
    raw_root = _find_colour_root(tmp_dir)

    print(f"[download_data] Found colour images at: {raw_root}")

    for pv_folder, canonical in PV_FOLDER_MAP.items():
        src = raw_root / pv_folder
        dst = dest_root / canonical
        dst.mkdir(parents=True, exist_ok=True)
        if not src.exists():
            raise FileNotFoundError(
                f"Expected folder not found: {src}\n"
                f"Check Kaggle dataset layout."
            )
        imgs = list(src.glob("*.jpg")) + list(src.glob("*.JPG")) \
             + list(src.glob("*.png")) + list(src.glob("*.PNG"))
        for img in imgs:
            shutil.copy2(img, dst / img.name)
        print(f"  {pv_folder} → {dst} ({len(imgs)} images)")

    # Cleanup temp download
    shutil.rmtree(tmp_dir, ignore_errors=True)
    print("[download_data] PlantVillage download complete.")
    _verify_counts(dest_root, silent=False)


def _find_colour_root(base: Path) -> Path:
    """Recursively find the folder containing Potato___* subfolders."""
    for p in base.rglob("Potato___Early_blight"):
        return p.parent
    raise FileNotFoundError(
        "Could not locate 'Potato___Early_blight' inside the downloaded archive. "
        "Check the Kaggle dataset structure."
    )


def _verify_counts(root: Path, silent: bool = False) -> bool:
    """Return True if all expected image counts are met."""
    ok = True
    for cls, expected in EXPECTED_COUNTS.items():
        cls_dir = root / cls
        if not cls_dir.exists():
            if not silent:
                print(f"  MISSING: {cls_dir}")
            ok = False
            continue
        imgs = (list(cls_dir.glob("*.jpg")) + list(cls_dir.glob("*.JPG"))
              + list(cls_dir.glob("*.png")) + list(cls_dir.glob("*.PNG")))
        count = len(imgs)
        status = "OK" if count == expected else f"WARNING (got {count}, expected {expected})"
        if not silent:
            print(f"  {cls}: {count} images — {status}")
        if count == 0:
            ok = False
    return ok


def check_fieldin(dest_root: str = C.FIELDIN_ROOT) -> None:
    """Verify Field-IN layout; print instructions if missing."""
    dest_root = Path(dest_root)
    expected = {"early_blight": 400, "late_blight": 400, "healthy": 400}
    missing = False
    print("\n[download_data] Checking Field-IN dataset ...")
    for cls, n in expected.items():
        cls_dir = dest_root / cls
        if not cls_dir.exists():
            print(f"  MISSING: {cls_dir}")
            missing = True
            continue
        imgs = (list(cls_dir.glob("*.jpg")) + list(cls_dir.glob("*.JPG"))
              + list(cls_dir.glob("*.png")) + list(cls_dir.glob("*.PNG")))
        print(f"  {cls}: {len(imgs)} / {n} images")
    if missing:
        print(
            "\n  Field-IN is a private dataset. Place images at:\n"
            f"    {dest_root}/early_blight/  (400 images)\n"
            f"    {dest_root}/late_blight/   (400 images)\n"
            f"    {dest_root}/healthy/       (400 images)\n"
            "  Contact corresponding author or Zenodo deposit for access."
        )


if __name__ == "__main__":
    download_plantvillage()
    check_fieldin()
